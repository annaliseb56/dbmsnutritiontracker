const colors = {
    cream: '#faf7f0',
    mint: '#e8f5e9',
    lightGreen: '#c8e6c9',
    sage: '#8ba887',
    darkGreen: '#4a5e4a',
    textDark: '#2c3e2e',
    tan: '#e0dbcfff'
} //color scheme from figma make

export default colors;
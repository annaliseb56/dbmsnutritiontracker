// Determine the API base URL
const getApiBaseUrl = () => {
  // In production, use relative /api path which NGINX proxies to Flask
  // In development, use localhost:5000
  if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
    return 'http://localhost:5000';
  }
  return '/api';
};

export const API_BASE_URL = getApiBaseUrl();
